//
//  MainView.swift
//  SnapkitSample
//
//  Created by Jung seoung Yeo on 2018. 5. 18..
//  Copyright © 2018년 Jung seoung Yeo. All rights reserved.
//
import Foundation
import Then
import SnapKit
import UIKit

class MainView: BaseView {
    
    let logo = UIImageView().then{
        $0.image = UIImage(named: "linsaeng")
        $0.contentMode = .scaleAspectFit
        $0.backgroundColor = .clear
    }
    
    let mainTitle = UILabel().then {
        $0.textAlignment = .center
        $0.numberOfLines = 0
        $0.font = .systemFont(ofSize: 26, weight: .medium)
        $0.text = """
        CodeSuard
        CodeReview
        """
    }
    
    override func setupView() {
        super.setupView()
        
        addsubViews(logo, mainTitle)
        
        logo.snp.makeConstraints{ make -> Void in
            make.top.equalTo(safeAreaInsets).offset(95)
            make.centerX.equalTo(self)
            make.size.equalTo(240)
        }
        
        mainTitle.snp.makeConstraints{ make -> Void in
            make.top.equalTo(logo.snp.bottom).offset(23)
            make.centerX.equalTo(self)
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
