//
//  MainVC.swift
//  SnapkitSample
//
//  Created by Jung seoung Yeo on 2018. 5. 18..
//  Copyright © 2018년 Jung seoung Yeo. All rights reserved.
//

import Foundation
import UIKit
import SnapKit
import Then

class MainVC : BaseVC {
    
    // 뷰를 생성
    var mainView = MainView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // 생성 된 뷰를 MainVC에 있는 view 에 넣어주는 부분
    override func settingView() {
        super.settingView()
        view = mainView
    }
}
