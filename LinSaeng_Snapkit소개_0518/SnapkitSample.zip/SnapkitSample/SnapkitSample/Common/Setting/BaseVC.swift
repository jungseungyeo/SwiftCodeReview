//
//  BaseVC.swift
//  SnapkitSample
//
//  Created by Jung seoung Yeo on 2018. 5. 18..
//  Copyright © 2018년 Jung seoung Yeo. All rights reserved.
//

import UIKit

class BaseVC: UIViewController {
    
    // 뷰 컨트롤러에서 setting() 함수 실행
    override func viewDidLoad() {
        super.viewDidLoad()
        settingView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // 뷰를 세팅하기 위한 함수
    func settingView() {
        self.view.backgroundColor = .white
    }
}
