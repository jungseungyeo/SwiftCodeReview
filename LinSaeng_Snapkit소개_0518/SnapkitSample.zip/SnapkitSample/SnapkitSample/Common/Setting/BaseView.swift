//
//  BaseView.swift
//  SnapkitSample
//
//  Created by Jung seoung Yeo on 2018. 5. 18..
//  Copyright © 2018년 Jung seoung Yeo. All rights reserved.
//

import UIKit

class BaseView: UIView {
    
    // view를 생성하는 함수
    func setupView() {
        backgroundColor = .white
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
