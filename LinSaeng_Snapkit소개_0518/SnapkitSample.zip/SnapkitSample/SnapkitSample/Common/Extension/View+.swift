//
//  View+.swift
//  SnapkitSample
//
//  Created by Jung seoung Yeo on 2018. 5. 18..
//  Copyright © 2018년 Jung seoung Yeo. All rights reserved.
//

import UIKit

extension UIView {
    
    // Snapkit에서 addsubView를 하기 위한 함수
    func addsubViews(_ views: UIView...){
        for view in views {
            addSubview(view)
        }
    }
}
